clc;clear;close all;
source = input('please enter your source value:','s');
x=input('node x: ');
y=input('node y: ');
file=fopen('input1.txt');
n=length(readlines("input1.txt"));
Elemans = Eleman.empty(n:0);
for i=1:n
    line = fgetl(file);
    Elemans(i)= readEleman(line,source);
end
fclose(file);
Elemans=solveC(Elemans,numberOfNodes(Elemans));
out=fopen('output4.txt','wt');
Finalize(out,Elemans,source,x,y);

fclose(out);

function el = readEleman(inputLine,source)
syms s real
input = split(convertCharsToStrings(inputLine),",");
if(input(1)=="ML")
    el = Eleman(convertStringsToChars(input(1)), ...
        convertStringsToChars(input(2)), ...
        str2double(input(3)), ...
        str2double(input(4)), ...
        str2double(input(5))*s, ...
        convertStringsToChars(input(6)), ...
        str2double(input(7)), ...
        str2double(input(8)), ...
        str2double(input(9))*s, ...
        str2double(input(10))*s);
elseif ((input(1)=='Z')||(input(1)=='H')||(input(1)=='Y')||(input(1)=='T'))
    el = Eleman(convertStringsToChars(input(1)), ...
        convertStringsToChars(input(2)), ...
        str2double(input(3)), ...
        str2double(input(4)), ...
        str2double(input(5)), ...
        str2double(input(6)), ...
        str2double(input(7)),0,0,0);
else
    if((input(1)=="L")||(input(1)=="C"))
        val=str2double(input(5))*s;
    elseif((input(1)=="V")||(input(1)=="I"))
        if(input(5)=='-')
           input(5)=source; 
        end
        val=laplace(str2sym(input(5)));
        
    else
        val=str2double(input(5));
    end
    el = Eleman(convertStringsToChars(input(1)), ...
        convertStringsToChars(input(2)), ...
        str2double(input(3)), ...
        str2double(input(4)),val,0,0,0,0,0);
end
end
%% analysis
%% analysis
function [Els] = solveC(Els,num)
    M1 = zeros(num+1);
    M2 = zeros(1,num+1);
    M1=sym(M1);
    M2=sym(M2);
    for e = Els
        if e.type=='R'
            M1(e.node1+1,e.node1+1) = M1(e.node1+1,e.node1+1)+1./e.value;
            M1(e.node2+1,e.node2+1) = M1(e.node2+1,e.node2+1)+1./e.value;
            M1(e.node1+1,e.node2+1) = M1(e.node1+1,e.node2+1)-1./e.value;
            M1(e.node2+1,e.node1+1) = M1(e.node2+1,e.node1+1)-1./e.value;
        elseif e.type=='C'
            M1(e.node1+1,e.node1+1) = M1(e.node1+1,e.node1+1)+e.value;
            M1(e.node2+1,e.node2+1) = M1(e.node2+1,e.node2+1)+e.value;
            M1(e.node1+1,e.node2+1) = M1(e.node1+1,e.node2+1)-e.value;
            M1(e.node2+1,e.node1+1) = M1(e.node2+1,e.node1+1)-e.value;
        elseif e.type=='L'
            M1(e.node1+1,e.node1+1) = M1(e.node1+1,e.node1+1)+1./e.value;
            M1(e.node2+1,e.node2+1) = M1(e.node2+1,e.node2+1)+1./e.value;
            M1(e.node1+1,e.node2+1) = M1(e.node1+1,e.node2+1)-1./e.value;
            M1(e.node2+1,e.node1+1) = M1(e.node2+1,e.node1+1)-1./e.value;
        elseif e.type=="ML"
            M1 = addRowColumn(M1);
            M1 = addRowColumn(M1);
            M2 = addColumn(M2);
            M2 = addColumn(M2);
            M1(end-1,e.node1_1+1) = 1;
            M1(end-1,e.node2_1+1) = -1;
            M1(end-1,end-1) = -e.value1;
            M1(end-1,end) = -e.mutual_inductance;
            M1(end,e.node1_2+1) = 1;
            M1(end,e.node2_2+1) = -1;
            M1(end,end-1) = -e.mutual_inductance;
            M1(end,end) = -e.value2;
            M1(e.node1_1,end-1) = 1;
            M1(e.node2_1,end-1) = -1;
            M1(e.node1_2,end) = 1;
            M1(e.node2_2,end) = -1;
        elseif e.type=='H'
            M1(e.node1+1,e.dependent_node1+1) = M1(e.node1+1,e.dependent_node1+1)+e.value;
            M1(e.node1+1,e.dependent_node2+1) = M1(e.node1+1,e.dependent_node2+1)-e.value;
            M1(e.node2+1,e.dependent_node1+1) = M1(e.node2+1,e.dependent_node1+1)-e.value;
            M1(e.node2+1,e.dependent_node2+1) = M1(e.node2+1,e.dependent_node2+1)+e.value;
        elseif e.type=='Z'
            M1 = addRowColumn(M1);
            M2 = addColumn(M2);
            M1(end,e.dependent_node1+1) = -e.value;
            M1(end,e.dependent_node2+1) = e.value;
            M1(end,e.node1+1) = 1;
            M1(end,e.node2+1) = -1;
            M1(e.node1+1,end) = 1;
            M1(e.node2+1,end) = -1;
        elseif e.type=='T'
            M1 = addRowColumn(M1);
            M2 = addColumn(M2);
            M1(end,e.dependent_node1+1) = 1;
            M1(end,e.dependent_node2+1) = -1;
            M1(e.dependent_node1+1,end) = 1;
            M1(e.dependent_node2+1,end) = -1;
            M1(e.node1+1,end) = e.value;
            M1(e.node2+1,end) = -e.value;
        elseif e.type=='Y'
            M1 = addRowColumn(M1);
            M1 = addRowColumn(M1);
            M2 = addColumn(M2);
            M2 = addColumn(M2);
            M1(e.dependent_node1+1,end-1) = 1;
            M1(e.dependent_node2+1,end-1) = -1;
            M1(e.node1+1,end) = 1;
            M1(e.node1+1,end) = -1;
            M1(end,end) = -e.value;
            M1(end-1,e.dependent_node1+1) = 1;
            M1(end-1,e.dependent_node2+1) = -1;
            M1(end,e.node1+1) = 1;
            M1(end,e.node2+1) = -1;
        elseif e.type=='V'
            M1 = addRowColumn(M1);
            M2 = addColumn(M2);
            M2(end) = e.value;
            M1(end,e.node1+1) = 1;
            M1(end,e.node2+1) = -1;
            M1(e.node1+1,end) = 1;
            M1(e.node2+1,end) = -1;
        elseif e.type=='I'
            M2(e.node1+1)=M2(e.node1+1)-e.value;
            M2(e.node2+1)=M2(e.node2+1)+e.value;
        end
    end
    G=M1;
    G(1,:)=[];
    G(:,1)=[];
    Y=M2(2:end);
    X=inv(G)*Y';
    X2=[0 X'];
    n=num+2;
    for i=1:length(Els)
        if Els(i).type == 'V'
            Els(i).voltage = Els(i).value;
            Els(i).current = 1;
            n = n + 1;
       elseif Els(i).type == 'I'
           Els(i).current = Els(i).value;
           Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
       elseif Els(i).type == 'R'
           Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
           Els(i).current = Els(i).voltage./Els(i).value;
        elseif Els(i).type == 'C'
           Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
           Els(i).current = Els(i).voltage.*Els(i).value;
        elseif Els(i).type == 'L'
           Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
           Els(i).current = Els(i).voltage./Els(i).value;
           n = n + 1;
        elseif Els(i).type == "ML"
            Els(i).voltage1 = X2(Els.node1_1+1)-X2(Els(i).node2_1+1);
            Els(i).current1 = X2(n);
            n = n + 1;
            Els(i).voltage2 = X2(Els.node1_2+1)-X2(Els(i).node2_2+1);
            Els(i).current2 = X2(n);
            n = n + 1;
        elseif Els(i).type == 'H'
            Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
            Els(i).current = Els(i).voltage.*Els(i).value;
        elseif Els(i).type == 'Z'
            Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
            Els(i).current = X2(n);
            n = n + 1;
        elseif Els(i).type == 'T'
            Els(i).voltage = X2(Els(i).node1+1)-X2(Els(i).node2+1);
            Els(i).current = X2(n).*Els(i).value;
            n = n + 1;
        elseif Els(i).type == 'Y'
            Els(i).voltage = X2(n).*Els(i).value;
            n = n + 1;
            Els(i).current = X2(n);
            n = n + 1;
       end
    end
    
end



function n = numberOfNodes(Elemans)
n=0;
for Eleman = Elemans
    if Eleman.type == "ML"
        if(Eleman.node1_1>n)
            n = Eleman.node1_1;
        end
        if(Eleman.node2_1>n)
            n = Eleman.node2_1;
        end
        if(Eleman.node1_2>n)
            n = Eleman.node1_2;
        end
        if(Eleman.node2_2>n)
            n = Eleman.node2_2;
        end
    else
        if(Eleman.node1>n)
            n = Eleman.node1;
        end
        if(Eleman.node2>n)
            n = Eleman.node2;
        end
        if ((Eleman.type=='Z')||(Eleman.type=='H')||(Eleman.type=='Y')||(Eleman.type=='T'))
            if(Eleman.dependent_node1>n)
                n = Eleman.dependent_node1;
            end
            if(Eleman.dependent_node2>n)
                n = Eleman.dependent_node2;
            end
        end
    end
    
end
end
function A2 = addRowColumn(A)
    A2 = zeros(size(A,1)+1, size(A,2)+1);
    A2=sym(A2);
    A2(1:size(A,1), 1:size(A,2)) = A;
end
function A2 = addColumn(A)
    A2 = zeros(1, size(A,2)+1);
    A2=sym(A2);
    A2(1, 1:size(A,2)) = A;
end
function Finalize(out,Els,source,x,y)
    sourceS=laplace(str2sym(source));
    b=0;
    for E = Els
        if E.type == "ML"
            fprintf(out,convertCharsToStrings(E.name1)+","+string(ilaplace(E.voltage1))+","+string(ilaplace(E.current1))+"\n");
            fprintf(out,convertCharsToStrings(E.name2)+","+string(ilaplace(E.voltage2))+","+string(ilaplace(E.current2))+"\n");
            disp(3);
             if(((E.node1_1==x&&E.node2_1==y)||(E.node1_1==y&&E.node2_1==x))&&b==0)
                b=1;
           Ts= simplify(sourceS.\E.voltage1)
           Tt=ilaplace(Ts);
           Vout=E.voltage1
           Voutt=simplify(ilaplace(Vout));
           fplot(Tt);
            figure
           fplot(Voutt)
            grid on;
             elseif(((E.node1_2==x&&E.node2_2==y)||(E.node1_2==y&&E.node2_2==x))&&b==0)
                b=1;
           Ts= simplify(sourceS.\E.voltage1)
           Tt=ilaplace(Ts);
           Vout=E.voltage2
           Voutt=simplify(ilaplace(Vout));
           fplot(Tt);
            figure
           fplot(Voutt)
            grid on;
             end
        else
        fprintf(out,convertCharsToStrings(E.name)+","+string(ilaplace(E.voltage))+","+string(ilaplace(E.current))+"\n"); 
         if(((E.node1==x&&E.node2==y)||(E.node1==y&&E.node2==x))&&b==0)
            b=1;
           %% disp('T(s)= ')
           Ts= simplify(sourceS.\E.voltage)
           Tt=ilaplace(Ts);
           Vout=E.voltage
           Voutt=simplify(ilaplace(Vout));
           fplot(Tt);
            figure
           fplot(Voutt)

            grid on;
        end
        end
       
    end
end